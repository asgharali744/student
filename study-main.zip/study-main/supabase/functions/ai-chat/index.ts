import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface RequestBody {
  messages: Message[];
  language?: string;
  type?: string;
  filename?: string;
  pdfBase64?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: RequestBody = await req.json();
    const { messages, language = "en", type = "chat" } = body;

    const geminiKey = Deno.env.get("GEMINI_API_KEY");
    const openaiKey = Deno.env.get("OPENAI_API_KEY");

    let responseContent = "";

    if (geminiKey) {
      responseContent = await callGemini(geminiKey, messages, language, type);
    } else if (openaiKey) {
      responseContent = await callOpenAI(openaiKey, messages, language, type);
    } else {
      responseContent = generateFallback(messages, language, type);
    }

    return new Response(JSON.stringify({ content: responseContent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(
      JSON.stringify({ content: "I encountered an error processing your request. Please try again.", error: String(error) }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function callGemini(apiKey: string, messages: Message[], language: string, type: string): Promise<string> {
  const systemPrompt = buildSystemPrompt(language, type);
  const contents = [
    { role: "user", parts: [{ text: systemPrompt }] },
    { role: "model", parts: [{ text: "Understood! I'm ready to help." }] },
    ...messages.map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    })),
  ];

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents, generationConfig: { temperature: 0.7, maxOutputTokens: 2048 } }),
    }
  );

  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || "I couldn't generate a response. Please try again.";
}

async function callOpenAI(apiKey: string, messages: Message[], language: string, type: string): Promise<string> {
  const systemPrompt = buildSystemPrompt(language, type);
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "system", content: systemPrompt }, ...messages],
      temperature: 0.7,
      max_tokens: 2048,
    }),
  });
  const data = await response.json();
  return data?.choices?.[0]?.message?.content || "I couldn't generate a response.";
}

function buildSystemPrompt(language: string, type: string): string {
  const langInstruction = language === "ur"
    ? "Respond primarily in Urdu (اردو). You can mix Urdu and English if needed for technical terms."
    : "Respond in English.";

  const typeInstructions: Record<string, string> = {
    chat: "You are StudyNova AI, an intelligent study assistant for students. Help with homework, explain concepts clearly, solve problems step-by-step, and make learning engaging.",
    notes: "You are StudyNova AI. Generate well-structured, comprehensive study notes. Use proper headings, bullet points, and formatting. Make notes concise yet thorough for exam preparation.",
    quiz: "You are StudyNova AI. Generate high-quality multiple choice questions with clear options and detailed explanations. Ensure questions are educationally valuable.",
    translate: "You are StudyNova AI. Provide accurate, natural-sounding translations. Preserve the meaning and tone of the original text.",
    grammar: "You are StudyNova AI. Correct grammar errors and improve text clarity while preserving the original meaning.",
    pdf: "You are StudyNova AI. Analyze the provided content and extract key information, summaries, and important notes for student learning.",
  };

  return `${typeInstructions[type] || typeInstructions.chat}\n\n${langInstruction}\n\nAlways be helpful, accurate, and student-friendly.`;
}

function generateFallback(messages: Message[], language: string, type: string): string {
  const lastMessage = messages[messages.length - 1]?.content || "";

  if (type === "quiz") {
    return JSON.stringify([
      {
        question: `What is the main topic of: "${lastMessage.slice(0, 30)}..."?`,
        options: ["Option A", "Option B", "Option C", "Option D"],
        correct: 0,
        explanation: "This is a sample question. Configure your AI API key for real quizzes."
      }
    ]);
  }

  if (language === "ur") {
    return `آپ کا سوال موصول ہوا: "${lastMessage.slice(0, 50)}"\n\nبراہ کرم نوٹ کریں کہ AI فیچرز کے لیے GEMINI_API_KEY یا OPENAI_API_KEY سیٹ کرنا ضروری ہے۔ اس وقت ڈیمو موڈ میں چل رہا ہے۔`;
  }

  return `I received your message: "${lastMessage.slice(0, 50)}..."\n\n**Note:** To enable full AI responses, please configure either GEMINI_API_KEY or OPENAI_API_KEY in the Supabase Edge Function secrets.\n\nCurrently running in demo mode. The platform structure, authentication, notes saving, quiz tracking, and all other features are fully functional!`;
}
