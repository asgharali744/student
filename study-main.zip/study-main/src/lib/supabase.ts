import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  avatar_url: string;
  role: string;
  plan: string;
  credits: number;
  language_preference: string;
  created_at: string;
  updated_at: string;
};

export type Chat = {
  id: string;
  user_id: string;
  title: string;
  model: string;
  language: string;
  created_at: string;
  updated_at: string;
};

export type ChatMessage = {
  id: string;
  chat_id: string;
  user_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
};

export type Note = {
  id: string;
  user_id: string;
  title: string;
  content: string;
  note_type: string;
  topic: string;
  tags: string[];
  is_pinned: boolean;
  created_at: string;
  updated_at: string;
};

export type Quiz = {
  id: string;
  user_id: string;
  title: string;
  topic: string;
  difficulty: string;
  questions: QuizQuestion[];
  score: number;
  completed: boolean;
  created_at: string;
};

export type QuizQuestion = {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
};

export type PdfUpload = {
  id: string;
  user_id: string;
  filename: string;
  file_url: string;
  extracted_text: string;
  summary: string;
  key_points: string[];
  mcqs: QuizQuestion[];
  important_notes: string;
  created_at: string;
};
