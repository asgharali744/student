import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  glass?: boolean;
  hover?: boolean;
}

export default function Card({ children, className = '', glass = false, hover = false }: CardProps) {
  return (
    <div
      className={`
        rounded-2xl border border-white/10
        ${glass ? 'bg-white/5 backdrop-blur-xl' : 'bg-slate-800/60'}
        ${hover ? 'transition-all duration-300 hover:border-blue-500/30 hover:shadow-xl hover:shadow-blue-500/10 hover:-translate-y-1' : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
}
