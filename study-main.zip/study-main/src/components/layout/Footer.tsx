import { Link } from 'react-router-dom';
import { Zap, Twitter, Github, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-bold text-white">StudyNova AI</span>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed">
              AI-powered study assistant for students. Solve homework, summarize PDFs, and learn smarter.
            </p>
            <div className="flex items-center gap-3 mt-4">
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors"><Twitter className="w-4 h-4" /></a>
              <a href="#" className="text-gray-500 hover:text-gray-300 transition-colors"><Github className="w-4 h-4" /></a>
              <a href="mailto:hello@studynova.ai" className="text-gray-500 hover:text-gray-300 transition-colors"><Mail className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Product */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Product</h4>
            <ul className="space-y-2">
              {[['Features', '/features'], ['Pricing', '/pricing'], ['AI Chat', '/chat'], ['Dashboard', '/dashboard']].map(([label, href]) => (
                <li key={href}>
                  <Link to={href} className="text-gray-500 hover:text-gray-300 text-sm transition-colors">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Resources</h4>
            <ul className="space-y-2">
              {[['Contact', '/contact'], ['Privacy Policy', '/privacy'], ['Terms of Service', '/terms']].map(([label, href]) => (
                <li key={href}>
                  <Link to={href} className="text-gray-500 hover:text-gray-300 text-sm transition-colors">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Languages */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Supported Languages</h4>
            <ul className="space-y-2 text-sm text-gray-500">
              <li>English</li>
              <li>Urdu (اردو)</li>
              <li>Hindi (हिंदी)</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-600 text-sm">
            &copy; {new Date().getFullYear()} StudyNova AI. All rights reserved.
          </p>
          <div className="flex items-center gap-1 text-xs text-gray-600">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            All systems operational
          </div>
        </div>
      </div>
    </footer>
  );
}
