import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, MessageSquare, FileText, BookOpen,
  BrainCircuit, Languages, Zap, LogOut, User, Shield, X
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '/dashboard' },
  { icon: MessageSquare, label: 'AI Chat', href: '/chat' },
  { icon: FileText, label: 'PDF Summary', href: '/pdf-summary' },
  { icon: BookOpen, label: 'Notes Generator', href: '/notes' },
  { icon: BrainCircuit, label: 'Quiz Generator', href: '/quiz' },
  { icon: Languages, label: 'Translator', href: '/translate' },
];

interface Props {
  mobileOpen?: boolean;
  onClose?: () => void;
}

export default function DashboardSidebar({ mobileOpen, onClose }: Props) {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  const isAdmin = profile?.role === 'admin';

  const content = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-bold text-sm text-white">StudyNova AI</span>
        </div>
        {onClose && (
          <button onClick={onClose} className="text-gray-400 hover:text-white md:hidden">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map(({ icon: Icon, label, href }) => (
          <NavLink
            key={href}
            to={href}
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`
            }
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            {label}
          </NavLink>
        ))}

        {isAdmin && (
          <div className="pt-3 mt-3 border-t border-white/10">
            <NavLink
              to="/admin"
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-yellow-600/20 text-yellow-400 border border-yellow-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`
              }
            >
              <Shield className="w-4 h-4 flex-shrink-0" />
              Admin Panel
            </NavLink>
          </div>
        )}
      </nav>

      {/* User Footer */}
      <div className="px-3 py-3 border-t border-white/10">
        <NavLink
          to="/profile"
          onClick={onClose}
          className={({ isActive }) =>
            `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all mb-1 ${
              isActive ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`
          }
        >
          <User className="w-4 h-4" />
          Profile
        </NavLink>
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>

        {/* Credits */}
        <div className="mt-3 px-3 py-2 bg-blue-600/10 border border-blue-500/20 rounded-xl">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-gray-400">AI Credits</span>
            <span className="text-xs font-bold text-blue-400">{profile?.credits ?? 0}</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-1.5">
            <div
              className="bg-gradient-to-r from-blue-500 to-cyan-400 h-1.5 rounded-full transition-all"
              style={{ width: `${Math.min(100, ((profile?.credits ?? 0) / 20) * 100)}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {profile?.plan === 'free' ? 'Free Plan' : 'Premium Plan'}
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <aside className="hidden md:flex flex-col w-60 bg-slate-800/50 border-r border-white/10 h-screen sticky top-0">
        {content}
      </aside>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
          <aside className="relative z-10 flex flex-col w-64 bg-slate-900 h-full">
            {content}
          </aside>
        </div>
      )}
    </>
  );
}
