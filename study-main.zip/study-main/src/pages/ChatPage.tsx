import { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Send, Copy, Check, Plus, Trash2, Globe, Mic } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Chat, ChatMessage } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import { TypingDots } from '../components/ui/Loader';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

type UIMessage = { role: 'user' | 'assistant'; content: string; id?: string };

export default function ChatPage() {
  const { user } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [language, setLanguage] = useState<'en' | 'ur'>('en');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!user) return;
    loadChats();
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function loadChats() {
    const { data } = await supabase
      .from('chats')
      .select('*')
      .eq('user_id', user!.id)
      .order('updated_at', { ascending: false })
      .limit(30);
    if (data) setChats(data as Chat[]);
  }

  async function createChat() {
    const { data } = await supabase
      .from('chats')
      .insert({ user_id: user!.id, title: 'New Chat', language })
      .select()
      .single();
    if (data) {
      setChats(prev => [data as Chat, ...prev]);
      setActiveChat(data as Chat);
      setMessages([]);
    }
  }

  async function loadChatMessages(chat: Chat) {
    setActiveChat(chat);
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('chat_id', chat.id)
      .order('created_at', { ascending: true });
    if (data) setMessages(data as UIMessage[]);
  }

  async function deleteChat(chatId: string) {
    await supabase.from('chats').delete().eq('id', chatId);
    setChats(prev => prev.filter(c => c.id !== chatId));
    if (activeChat?.id === chatId) { setActiveChat(null); setMessages([]); }
  }

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    textareaRef.current?.focus();

    let chat = activeChat;
    if (!chat) {
      const { data } = await supabase
        .from('chats')
        .insert({ user_id: user!.id, title: userMsg.slice(0, 40), language })
        .select().single();
      if (data) { chat = data as Chat; setChats(prev => [data as Chat, ...prev]); setActiveChat(data as Chat); }
    }
    if (!chat) return;

    const userMsgObj: UIMessage = { role: 'user', content: userMsg };
    setMessages(prev => [...prev, userMsgObj]);
    setLoading(true);

    await supabase.from('chat_messages').insert({ chat_id: chat.id, user_id: user!.id, role: 'user', content: userMsg });

    try {
      const historyForAI = [...messages, userMsgObj].slice(-10).map(m => ({ role: m.role, content: m.content }));
      const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
        body: JSON.stringify({ messages: historyForAI, language }),
      });
      const result = await response.json();
      const aiContent = result.content || 'Sorry, I could not process that request.';

      const aiMsg: UIMessage = { role: 'assistant', content: aiContent };
      setMessages(prev => [...prev, aiMsg]);
      await supabase.from('chat_messages').insert({ chat_id: chat!.id, user_id: user!.id, role: 'assistant', content: aiContent });
      await supabase.from('chats').update({ updated_at: new Date().toISOString() }).eq('id', chat!.id);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error. Please try again.' }]);
    }
    setLoading(false);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  }

  async function copyToClipboard(text: string, id: string) {
    await navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  function handleVoiceInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech recognition not supported in your browser.');
      return;
    }
    const SpeechRecognition = (window as unknown as { webkitSpeechRecognition: typeof window.SpeechRecognition }).webkitSpeechRecognition || window.SpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = language === 'ur' ? 'ur-PK' : 'en-US';
    recognition.onresult = (e: SpeechRecognitionEvent) => setInput(prev => prev + e.results[0][0].transcript);
    recognition.start();
  }

  return (
    <DashboardLayout>
      <div className="flex h-[calc(100vh-56px)] md:h-screen">
        {/* Chat List Sidebar */}
        <div className="hidden sm:flex flex-col w-56 bg-slate-800/40 border-r border-white/10">
          <div className="p-3 border-b border-white/10">
            <button
              onClick={createChat}
              className="w-full flex items-center gap-2 bg-blue-600/20 border border-blue-500/30 hover:bg-blue-600/30 rounded-xl px-3 py-2 text-blue-300 text-sm font-medium transition-all"
            >
              <Plus className="w-4 h-4" /> New Chat
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {chats.map(chat => (
              <div
                key={chat.id}
                onClick={() => loadChatMessages(chat)}
                className={`group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer text-sm transition-all ${
                  activeChat?.id === chat.id
                    ? 'bg-blue-600/20 text-white border border-blue-500/30'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <span className="flex-1 truncate">{chat.title}</span>
                <button
                  onClick={e => { e.stopPropagation(); deleteChat(chat.id); }}
                  className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 transition-opacity"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Main Chat */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-slate-800/30">
            <div className="flex items-center gap-2">
              <h2 className="font-semibold text-white text-sm">{activeChat?.title || 'AI Chat'}</h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLanguage(language === 'en' ? 'ur' : 'en')}
                className="flex items-center gap-1.5 bg-white/5 border border-white/10 hover:bg-white/10 rounded-lg px-3 py-1.5 text-xs text-gray-300 transition-all"
              >
                <Globe className="w-3.5 h-3.5" />
                {language === 'en' ? 'English' : 'اردو'}
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
            {messages.length === 0 && !loading && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <Send className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">Start a conversation</h3>
                <p className="text-gray-500 text-sm max-w-sm">
                  Ask anything in English or Urdu. Solve homework, explain concepts, or get study help.
                </p>
                <div className="mt-6 flex flex-wrap gap-2 justify-center">
                  {['Explain photosynthesis', 'Solve: 2x + 5 = 15', 'تاریخ پاکستان کیا ہے؟'].map(q => (
                    <button
                      key={q}
                      onClick={() => setInput(q)}
                      className="text-xs bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'assistant' && (
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-white mt-1">AI</div>
                )}
                <div
                  className={`group relative max-w-[85%] sm:max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-blue-600 text-white rounded-tr-sm'
                      : 'bg-slate-700/80 text-gray-100 rounded-tl-sm border border-white/10'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                  {msg.role === 'assistant' && (
                    <button
                      onClick={() => copyToClipboard(msg.content, String(i))}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-gray-400 hover:text-gray-200 transition-all"
                    >
                      {copied === String(i) ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 bg-gradient-to-br from-gray-600 to-gray-500 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-white mt-1">
                    U
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-white">AI</div>
                <div className="bg-slate-700/80 border border-white/10 rounded-2xl rounded-tl-sm">
                  <TypingDots />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="px-4 pb-4 pt-2 border-t border-white/10">
            <div className="flex items-end gap-2 bg-slate-700/50 border border-white/10 rounded-2xl px-4 py-3 focus-within:border-blue-500/40 transition-all">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={language === 'ur' ? 'اپنا سوال یہاں لکھیں...' : 'Ask anything... (Enter to send, Shift+Enter for newline)'}
                rows={1}
                className="flex-1 bg-transparent text-white placeholder:text-gray-500 text-sm resize-none focus:outline-none max-h-32 leading-relaxed"
                style={{ direction: language === 'ur' ? 'rtl' : 'ltr' }}
              />
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={handleVoiceInput}
                  className="text-gray-500 hover:text-blue-400 transition-colors p-1"
                  title="Voice input"
                >
                  <Mic className="w-4 h-4" />
                </button>
                <button
                  onClick={sendMessage}
                  disabled={!input.trim() || loading}
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                    input.trim() && !loading
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'bg-white/5 text-gray-600 cursor-not-allowed'
                  }`}
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
            <p className="text-xs text-gray-600 text-center mt-2">AI can make mistakes. Verify important information.</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
