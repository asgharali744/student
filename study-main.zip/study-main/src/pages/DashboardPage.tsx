import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  MessageSquare, FileText, BookOpen, BrainCircuit, Languages,
  Zap, TrendingUp, Clock, Star, ArrowRight
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';

const tools = [
  { icon: MessageSquare, label: 'AI Chat', href: '/chat', color: 'from-blue-500 to-cyan-400', desc: 'Chat with AI' },
  { icon: FileText, label: 'PDF Summary', href: '/pdf-summary', color: 'from-emerald-500 to-teal-400', desc: 'Summarize PDFs' },
  { icon: BookOpen, label: 'Notes', href: '/notes', color: 'from-orange-500 to-amber-400', desc: 'Generate notes' },
  { icon: BrainCircuit, label: 'Quiz', href: '/quiz', color: 'from-pink-500 to-rose-400', desc: 'Create quizzes' },
  { icon: Languages, label: 'Translate', href: '/translate', color: 'from-teal-500 to-cyan-400', desc: 'Translate text' },
];

type StatCounts = { chats: number; notes: number; quizzes: number; pdfs: number };

export default function DashboardPage() {
  const { user, profile } = useAuth();
  const [counts, setCounts] = useState<StatCounts>({ chats: 0, notes: 0, quizzes: 0, pdfs: 0 });
  const [recentNotes, setRecentNotes] = useState<{ id: string; title: string; topic: string; created_at: string }[]>([]);

  useEffect(() => {
    if (!user) return;
    async function load() {
      const [chats, notes, quizzes, pdfs] = await Promise.all([
        supabase.from('chats').select('id', { count: 'exact', head: true }).eq('user_id', user!.id),
        supabase.from('notes').select('id', { count: 'exact', head: true }).eq('user_id', user!.id),
        supabase.from('quizzes').select('id', { count: 'exact', head: true }).eq('user_id', user!.id),
        supabase.from('pdf_uploads').select('id', { count: 'exact', head: true }).eq('user_id', user!.id),
      ]);
      setCounts({
        chats: chats.count ?? 0,
        notes: notes.count ?? 0,
        quizzes: quizzes.count ?? 0,
        pdfs: pdfs.count ?? 0,
      });
      const { data } = await supabase
        .from('notes')
        .select('id, title, topic, created_at')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false })
        .limit(5);
      if (data) setRecentNotes(data);
    }
    load();
  }, [user]);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-8">
        {/* Welcome */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">
              {greeting()}, {profile?.full_name?.split(' ')[0] || 'Student'}
            </h1>
            <p className="text-gray-400 text-sm mt-1">What would you like to study today?</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant={profile?.plan === 'free' ? 'gray' : 'blue'}>
              {profile?.plan === 'free' ? 'Free Plan' : 'Pro Plan'}
            </Badge>
            <div className="flex items-center gap-1.5 bg-blue-600/15 border border-blue-500/20 rounded-xl px-3 py-1.5">
              <Zap className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-sm font-semibold text-blue-300">{profile?.credits ?? 0} credits</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: MessageSquare, label: 'Chats', value: counts.chats, color: 'text-blue-400' },
            { icon: BookOpen, label: 'Notes', value: counts.notes, color: 'text-orange-400' },
            { icon: BrainCircuit, label: 'Quizzes', value: counts.quizzes, color: 'text-pink-400' },
            { icon: FileText, label: 'PDFs', value: counts.pdfs, color: 'text-emerald-400' },
          ].map(({ icon: Icon, label, value, color }) => (
            <Card key={label} className="p-4">
              <Icon className={`w-5 h-5 ${color} mb-2`} />
              <p className="text-2xl font-bold text-white">{value}</p>
              <p className="text-gray-500 text-xs">{label}</p>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {tools.map(({ icon: Icon, label, href, color, desc }) => (
              <Link
                key={href}
                to={href}
                className="group flex flex-col items-center gap-2 bg-slate-800/60 border border-white/10 rounded-xl p-4 hover:border-white/20 hover:-translate-y-1 transition-all duration-200 text-center"
              >
                <div className={`w-10 h-10 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-white text-sm font-medium">{label}</span>
                <span className="text-gray-500 text-xs">{desc}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Notes */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Recent Notes</h2>
            <Link to="/notes" className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {recentNotes.length === 0 ? (
            <Card className="p-8 text-center">
              <BookOpen className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No notes yet. Generate your first note!</p>
              <Link to="/notes" className="inline-block mt-3 text-blue-400 text-sm hover:text-blue-300">
                Generate notes →
              </Link>
            </Card>
          ) : (
            <div className="space-y-2">
              {recentNotes.map(note => (
                <Card key={note.id} className="p-4 flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-4 h-4 text-orange-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{note.title}</p>
                    <p className="text-gray-500 text-xs">{note.topic}</p>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600 text-xs">
                    <Clock className="w-3 h-3" />
                    {new Date(note.created_at).toLocaleDateString()}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Upgrade CTA */}
        {profile?.plan === 'free' && (
          <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border border-blue-500/30 rounded-2xl p-6 flex flex-col sm:flex-row items-center gap-4">
            <Star className="w-8 h-8 text-yellow-400 flex-shrink-0" />
            <div className="flex-1 text-center sm:text-left">
              <p className="font-semibold text-white">Upgrade to Pro</p>
              <p className="text-gray-400 text-sm">Get 500 credits/month, unlimited chat, PDF summaries & more.</p>
            </div>
            <Link to="/pricing">
              <button className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:from-blue-700 hover:to-cyan-600 transition-all whitespace-nowrap">
                Upgrade Now
              </button>
            </Link>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
