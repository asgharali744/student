import { useState } from 'react';
import { Languages, ArrowLeftRight, Copy, Check, Volume2 } from 'lucide-react';
import DashboardLayout from '../components/layout/DashboardLayout';
import Button from '../components/ui/Button';
import { Textarea } from '../components/ui/Input';
import Card from '../components/ui/Card';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

const LANGS = [
  { code: 'en', label: 'English' },
  { code: 'ur', label: 'Urdu (اردو)' },
  { code: 'hi', label: 'Hindi (हिंदी)' },
];

export default function TranslatePage() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [fromLang, setFromLang] = useState('en');
  const [toLang, setToLang] = useState('ur');
  const [translating, setTranslating] = useState(false);
  const [correcting, setCorrecting] = useState(false);
  const [copied, setCopied] = useState(false);

  async function translate() {
    if (!inputText.trim() || translating) return;
    setTranslating(true);
    setOutputText('');
    try {
      const fromLabel = LANGS.find(l => l.code === fromLang)?.label;
      const toLabel = LANGS.find(l => l.code === toLang)?.label;
      const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
        body: JSON.stringify({
          messages: [{ role: 'user', content: `Translate the following text from ${fromLabel} to ${toLabel}. Return ONLY the translated text with no explanation:\n\n${inputText}` }],
          language: toLang,
          type: 'translate',
        }),
      });
      const result = await response.json();
      setOutputText(result.content || 'Translation failed.');
    } catch { setOutputText('Translation error. Please try again.'); }
    setTranslating(false);
  }

  async function correctGrammar() {
    if (!inputText.trim() || correcting) return;
    setCorrecting(true);
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
        body: JSON.stringify({
          messages: [{ role: 'user', content: `Correct the grammar and improve the following text. Return ONLY the corrected text:\n\n${inputText}` }],
          language: fromLang,
          type: 'grammar',
        }),
      });
      const result = await response.json();
      setOutputText(result.content || 'Could not correct grammar.');
    } catch { setOutputText('Error. Please try again.'); }
    setCorrecting(false);
  }

  function swapLanguages() {
    setFromLang(toLang);
    setToLang(fromLang);
    setInputText(outputText);
    setOutputText(inputText);
  }

  async function copyOutput() {
    if (!outputText) return;
    await navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function speakText(text: string, lang: string) {
    if (!text || !('speechSynthesis' in window)) { alert('Text-to-speech not supported.'); return; }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'ur' ? 'ur-PK' : lang === 'hi' ? 'hi-IN' : 'en-US';
    window.speechSynthesis.speak(utterance);
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-xl font-bold text-white">AI Translator</h1>
          <p className="text-gray-400 text-sm">Translate between Urdu, English, and Hindi with AI grammar correction</p>
        </div>

        {/* Language Selector */}
        <Card glass className="p-4">
          <div className="flex items-center gap-3">
            <select
              value={fromLang}
              onChange={e => setFromLang(e.target.value)}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60"
            >
              {LANGS.map(l => <option key={l.code} value={l.code} className="bg-slate-800">{l.label}</option>)}
            </select>
            <button
              onClick={swapLanguages}
              className="p-2 bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition-all"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
            <select
              value={toLang}
              onChange={e => setToLang(e.target.value)}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60"
            >
              {LANGS.map(l => <option key={l.code} value={l.code} className="bg-slate-800">{l.label}</option>)}
            </select>
          </div>
        </Card>

        {/* Translation Area */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-400 uppercase">{LANGS.find(l => l.code === fromLang)?.label}</span>
              <button onClick={() => speakText(inputText, fromLang)} className="text-gray-500 hover:text-blue-400 transition-colors">
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
            <textarea
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              placeholder="Enter text to translate..."
              rows={8}
              style={{ direction: fromLang === 'ur' ? 'rtl' : 'ltr' }}
              className="w-full bg-transparent text-white placeholder:text-gray-600 text-sm resize-none focus:outline-none leading-relaxed"
            />
            <p className="text-gray-600 text-xs">{inputText.length} characters</p>
          </Card>

          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-400 uppercase">{LANGS.find(l => l.code === toLang)?.label}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => speakText(outputText, toLang)} className="text-gray-500 hover:text-blue-400 transition-colors">
                  <Volume2 className="w-4 h-4" />
                </button>
                <button onClick={copyOutput} className="text-gray-500 hover:text-blue-400 transition-colors">
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div
              className={`text-sm min-h-[8rem] leading-relaxed ${outputText ? 'text-gray-200' : 'text-gray-600'}`}
              style={{ direction: toLang === 'ur' ? 'rtl' : 'ltr' }}
            >
              {translating ? (
                <div className="flex items-center gap-2 text-blue-400">
                  <span className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
                  Translating...
                </div>
              ) : outputText || 'Translation will appear here...'}
            </div>
          </Card>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-3">
          <Button onClick={translate} loading={translating} icon={<Languages className="w-4 h-4" />}>
            Translate
          </Button>
          <Button variant="secondary" onClick={correctGrammar} loading={correcting}>
            Fix Grammar
          </Button>
          <Button variant="ghost" onClick={() => { setInputText(''); setOutputText(''); }}>
            Clear
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
}
