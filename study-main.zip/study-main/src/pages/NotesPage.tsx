import { useState, useEffect } from 'react';
import { BookOpen, Plus, Trash2, Copy, Check, Pin, Search } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Note } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Button from '../components/ui/Button';
import { Input, Textarea } from '../components/ui/Input';
import Card from '../components/ui/Card';
import { Spinner } from '../components/ui/Loader';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

const noteTypes = [
  { value: 'short', label: 'Short Notes' },
  { value: 'long', label: 'Long Notes' },
  { value: 'bullets', label: 'Bullet Points' },
  { value: 'exam', label: 'Exam Prep' },
];

export default function NotesPage() {
  const { user } = useAuth();
  const [topic, setTopic] = useState('');
  const [noteType, setNoteType] = useState('short');
  const [language, setLanguage] = useState('en');
  const [generating, setGenerating] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [search, setSearch] = useState('');
  const [copied, setCopied] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadNotes();
  }, [user]);

  async function loadNotes() {
    setLoading(true);
    const { data } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', user!.id)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false });
    if (data) setNotes(data as Note[]);
    setLoading(false);
  }

  async function generateNote() {
    if (!topic.trim() || generating) return;
    setGenerating(true);
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `Generate ${noteType} notes about: "${topic}". Language: ${language === 'ur' ? 'Urdu' : 'English'}. Format them well with headings.`
          }],
          language,
          type: 'notes',
        }),
      });
      const result = await response.json();
      const content = result.content || 'Could not generate notes.';
      const { data } = await supabase
        .from('notes')
        .insert({ user_id: user!.id, title: topic, content, note_type: noteType, topic })
        .select().single();
      if (data) setNotes(prev => [data as Note, ...prev]);
      setTopic('');
    } catch {
      alert('Error generating notes. Please try again.');
    }
    setGenerating(false);
  }

  async function deleteNote(id: string) {
    await supabase.from('notes').delete().eq('id', id);
    setNotes(prev => prev.filter(n => n.id !== id));
  }

  async function togglePin(note: Note) {
    await supabase.from('notes').update({ is_pinned: !note.is_pinned }).eq('id', note.id);
    setNotes(prev => prev.map(n => n.id === note.id ? { ...n, is_pinned: !n.is_pinned } : n));
  }

  async function copyNote(content: string, id: string) {
    await navigator.clipboard.writeText(content);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  const filtered = notes.filter(n =>
    n.title.toLowerCase().includes(search.toLowerCase()) ||
    n.topic.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-xl font-bold text-white">Notes Generator</h1>
          <p className="text-gray-400 text-sm">Generate AI-powered study notes from any topic</p>
        </div>

        {/* Generator */}
        <Card glass className="p-5 space-y-4">
          <Textarea
            label="Topic"
            placeholder="e.g. Photosynthesis, World War II, Newton's Laws..."
            value={topic}
            onChange={e => setTopic(e.target.value)}
            rows={3}
          />
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-40">
              <label className="text-xs font-medium text-gray-400 mb-1.5 block">Note Type</label>
              <select
                value={noteType}
                onChange={e => setNoteType(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60"
              >
                {noteTypes.map(t => <option key={t.value} value={t.value} className="bg-slate-800">{t.label}</option>)}
              </select>
            </div>
            <div className="flex-1 min-w-32">
              <label className="text-xs font-medium text-gray-400 mb-1.5 block">Language</label>
              <select
                value={language}
                onChange={e => setLanguage(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60"
              >
                <option value="en" className="bg-slate-800">English</option>
                <option value="ur" className="bg-slate-800">Urdu</option>
              </select>
            </div>
            <div className="flex items-end">
              <Button onClick={generateNote} loading={generating} icon={<Plus className="w-4 h-4" />}>
                Generate Notes
              </Button>
            </div>
          </div>
        </Card>

        {/* Search */}
        <Input
          placeholder="Search your notes..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          icon={<Search className="w-4 h-4" />}
        />

        {/* Notes List */}
        {loading ? (
          <div className="flex justify-center py-12"><Spinner /></div>
        ) : filtered.length === 0 ? (
          <Card className="p-10 text-center">
            <BookOpen className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">{search ? 'No notes found.' : 'No notes yet. Generate your first note above!'}</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map(note => (
              <Card key={note.id} className="p-4 flex flex-col gap-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-white text-sm truncate">{note.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500 bg-white/5 px-2 py-0.5 rounded-full">
                        {noteTypes.find(t => t.value === note.note_type)?.label}
                      </span>
                      <span className="text-xs text-gray-600">{new Date(note.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button onClick={() => togglePin(note)} className={`p-1.5 rounded-lg transition-colors ${note.is_pinned ? 'text-yellow-400 bg-yellow-400/10' : 'text-gray-500 hover:text-yellow-400 hover:bg-yellow-400/10'}`}>
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => copyNote(note.content, note.id)} className="p-1.5 rounded-lg text-gray-500 hover:text-blue-400 hover:bg-blue-400/10 transition-colors">
                      {copied === note.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => deleteNote(note.id)} className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-400/10 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed line-clamp-4 whitespace-pre-line">{note.content}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
