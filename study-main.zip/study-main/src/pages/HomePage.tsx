import { Link } from 'react-router-dom';
import {
  Zap, MessageSquare, FileText, BookOpen, BrainCircuit,
  Languages, ArrowRight, Star, Users, Globe, CheckCircle, Sparkles
} from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const features = [
  { icon: MessageSquare, title: 'AI Chat Assistant', desc: 'ChatGPT-style interface with Urdu & English support. Chat history saved automatically.', color: 'from-blue-500 to-cyan-400', href: '/chat' },
  { icon: FileText, title: 'PDF Summary Tool', desc: 'Upload PDFs and get instant summaries, key points, MCQs, and important notes.', color: 'from-emerald-500 to-teal-400', href: '/pdf-summary' },
  { icon: BookOpen, title: 'Notes Generator', desc: 'Generate short, long, bullet-point, or exam prep notes from any topic in seconds.', color: 'from-orange-500 to-amber-400', href: '/notes' },
  { icon: BrainCircuit, title: 'Quiz Generator', desc: 'Create AI-powered quizzes with multiple difficulty levels and instant answers.', color: 'from-pink-500 to-rose-400', href: '/quiz' },
  { icon: Languages, title: 'AI Translator', desc: 'Translate between Urdu, English, and Hindi with AI grammar correction.', color: 'from-violet-500 to-blue-400', href: '/translate' },
  { icon: Zap, title: 'Homework Solver', desc: 'Upload homework images — OCR extracts text and AI provides step-by-step solutions.', color: 'from-yellow-500 to-orange-400', href: '/chat' },
];

const stats = [
  { icon: Users, value: '50K+', label: 'Active Students' },
  { icon: Star, value: '4.9/5', label: 'Average Rating' },
  { icon: Globe, value: '3', label: 'Languages Supported' },
  { icon: Zap, value: '2M+', label: 'Questions Solved' },
];

const plans = [
  {
    name: 'Free', price: '$0', period: '/month',
    features: ['20 AI credits/month', 'AI Chat (10 msgs/day)', 'PDF Summary (2/month)', 'Basic Notes', 'Standard speed'],
    cta: 'Get Started Free', variant: 'ghost' as const, popular: false,
  },
  {
    name: 'Pro', price: '$9', period: '/month',
    features: ['500 AI credits/month', 'Unlimited Chat', 'PDF Summary (50/month)', 'Advanced Notes + Quizzes', 'Priority speed', 'Voice input', 'Export to PDF/Word'],
    cta: 'Start Pro', variant: 'primary' as const, popular: true,
  },
  {
    name: 'Elite', price: '$19', period: '/month',
    features: ['Unlimited AI credits', 'Everything in Pro', 'Unlimited PDFs', 'Admin tools', 'API access', 'Custom AI persona', 'Dedicated support'],
    cta: 'Go Elite', variant: 'secondary' as const, popular: false,
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />

      {/* Hero */}
      <section className="relative pt-32 pb-24 px-4 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl animate-pulse [animation-delay:1s]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-900/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-blue-600/15 border border-blue-500/30 rounded-full px-4 py-2 text-sm text-blue-300 mb-6 animate-fade-in">
            <Sparkles className="w-4 h-4" />
            Powered by Advanced AI — Study Smarter, Not Harder
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold leading-tight mb-6 tracking-tight">
            Your AI Study
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400">
              Companion for
            </span>
            Every Student
          </h1>

          <p className="text-gray-400 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Solve homework, summarize PDFs, generate notes, take quizzes, and chat with AI — all in one platform.
            Supports <strong className="text-white">Urdu</strong> and <strong className="text-white">English</strong>.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register">
              <Button size="lg" icon={<Zap className="w-5 h-5" />}>
                Start Learning Free
              </Button>
            </Link>
            <Link to="/features">
              <Button variant="ghost" size="lg" icon={<ArrowRight className="w-5 h-5" />}>
                Explore Features
              </Button>
            </Link>
          </div>

          <p className="text-gray-600 text-sm mt-4">No credit card required. 20 free AI credits on signup.</p>
        </div>

        {/* Preview */}
        <div className="relative max-w-4xl mx-auto mt-16">
          <div className="bg-slate-800/80 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl shadow-blue-500/10">
            <div className="flex items-center gap-2 px-4 py-3 bg-slate-700/50 border-b border-white/10">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
              </div>
              <span className="text-gray-400 text-xs ml-2">StudyNova AI — Chat</span>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold">S</div>
                <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-gray-300 max-w-sm">
                  What is the Pythagorean theorem and how do I use it? اردو میں بھی سمجھاؤ۔
                </div>
              </div>
              <div className="flex gap-3 justify-end">
                <div className="bg-blue-600/20 border border-blue-500/30 rounded-2xl rounded-tr-sm px-4 py-3 text-sm text-blue-100 max-w-md">
                  <p className="font-semibold mb-2">Pythagorean Theorem</p>
                  <p className="text-gray-300 mb-2">In a right triangle: <code className="bg-white/10 px-1 rounded text-blue-300">a² + b² = c²</code></p>
                  <p className="text-gray-400 text-xs">اردو: ایک قائم زاویہ مثلث میں، دو چھوٹی اضلاع کے مربعوں کا مجموعہ سب سے لمبی ضلع (وتر) کے مربع کے برابر ہوتا ہے۔</p>
                </div>
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex-shrink-0 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 px-4 border-y border-white/5">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map(({ icon: Icon, value, label }) => (
            <div key={label} className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-600/15 rounded-xl mb-2">
                <Icon className="w-5 h-5 text-blue-400" />
              </div>
              <p className="text-2xl font-bold text-white">{value}</p>
              <p className="text-gray-500 text-sm">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Everything You Need to Excel</h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">Six powerful AI tools built for students, all in one beautiful platform.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(({ icon: Icon, title, desc, color, href }) => (
              <Link key={title} to={href}>
                <Card hover className="p-6 group cursor-pointer h-full">
                  <div className={`w-11 h-11 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center mb-4 shadow-lg`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="font-semibold text-white mb-2 group-hover:text-blue-300 transition-colors">{title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
                  <div className="flex items-center gap-1 mt-4 text-blue-400 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Try it now <ArrowRight className="w-3 h-3" />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20 px-4 bg-slate-800/30">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Simple, Transparent Pricing</h2>
            <p className="text-gray-400 text-lg">Start free. Upgrade when you need more.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-2xl p-6 border transition-all ${
                  plan.popular
                    ? 'bg-blue-600/15 border-blue-500/50 shadow-xl shadow-blue-500/10'
                    : 'bg-slate-800/60 border-white/10'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                    Most Popular
                  </div>
                )}
                <div className="mb-6">
                  <p className="text-gray-400 text-sm font-medium">{plan.name}</p>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-3xl font-extrabold text-white">{plan.price}</span>
                    <span className="text-gray-500 text-sm">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-gray-300">
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link to="/register">
                  <Button variant={plan.variant} fullWidth>{plan.cta}</Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border border-blue-500/30 rounded-3xl p-10">
            <Zap className="w-12 h-12 text-blue-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Study Smarter?</h2>
            <p className="text-gray-400 mb-8">Join 50,000+ students already using StudyNova AI to ace their exams.</p>
            <Link to="/register">
              <Button size="lg" icon={<ArrowRight className="w-5 h-5" />}>
                Create Free Account
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
