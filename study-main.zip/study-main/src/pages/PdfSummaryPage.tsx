import { useState, useEffect, useRef } from 'react';
import { FileText, Upload, Trash2, ChevronDown, ChevronUp, Loader2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, PdfUpload } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { Spinner } from '../components/ui/Loader';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export default function PdfSummaryPage() {
  const { user } = useAuth();
  const [pdfs, setPdfs] = useState<PdfUpload[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  useEffect(() => { if (user) loadPdfs(); }, [user]);

  async function loadPdfs() {
    setLoading(true);
    const { data } = await supabase.from('pdf_uploads').select('*').eq('user_id', user!.id).order('created_at', { ascending: false });
    if (data) setPdfs(data as PdfUpload[]);
    setLoading(false);
  }

  async function handleFile(file: File) {
    if (!file || !file.name.endsWith('.pdf')) { alert('Please upload a PDF file.'); return; }
    if (file.size > 5 * 1024 * 1024) { alert('File too large. Max 5MB.'); return; }
    setProcessing(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const base64 = (e.target?.result as string).split(',')[1];
        const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
          body: JSON.stringify({
            type: 'pdf',
            filename: file.name,
            pdfBase64: base64,
            messages: [{ role: 'user', content: 'Analyze this PDF and provide: 1) Summary 2) Key Points (as JSON array) 3) Important Notes. Format as JSON: {"summary":"...","key_points":["..."],"important_notes":"..."}' }],
            language: 'en',
          }),
        });
        const result = await response.json();
        let summary = 'Could not process PDF content.';
        let key_points: string[] = [];
        let important_notes = '';
        try {
          const jsonMatch = result.content.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            summary = parsed.summary || summary;
            key_points = parsed.key_points || [];
            important_notes = parsed.important_notes || '';
          } else {
            summary = result.content;
          }
        } catch { summary = result.content; }

        const { data } = await supabase.from('pdf_uploads').insert({
          user_id: user!.id,
          filename: file.name,
          summary,
          key_points,
          important_notes,
          extracted_text: '',
        }).select().single();
        if (data) setPdfs(prev => [data as PdfUpload, ...prev]);
      } catch { alert('Error processing PDF. Please try again.'); }
      setProcessing(false);
    };
    reader.readAsDataURL(file);
  }

  async function deletePdf(id: string) {
    await supabase.from('pdf_uploads').delete().eq('id', id);
    setPdfs(prev => prev.filter(p => p.id !== id));
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-xl font-bold text-white">PDF Summary Tool</h1>
          <p className="text-gray-400 text-sm">Upload PDFs and get AI-powered summaries, key points, and notes</p>
        </div>

        {/* Upload Area */}
        <Card glass className="p-6">
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            className={`border-2 border-dashed rounded-xl p-10 text-center transition-all cursor-pointer ${
              dragOver ? 'border-blue-500 bg-blue-500/10' : 'border-white/20 hover:border-blue-500/50 hover:bg-blue-500/5'
            }`}
            onClick={() => !processing && fileRef.current?.click()}
          >
            <input ref={fileRef} type="file" accept=".pdf" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ''; }} />
            {processing ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-10 h-10 text-blue-400 animate-spin" />
                <p className="text-blue-300 font-medium">Processing PDF with AI...</p>
                <p className="text-gray-500 text-sm">This may take a moment</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-400 rounded-2xl flex items-center justify-center">
                  <Upload className="w-7 h-7 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">Drop PDF here or click to upload</p>
                  <p className="text-gray-500 text-sm mt-1">Max 5MB · PDF files only</p>
                </div>
                <Button variant="outline" size="sm">Choose File</Button>
              </div>
            )}
          </div>
        </Card>

        {/* PDF List */}
        {loading ? (
          <div className="flex justify-center py-8"><Spinner /></div>
        ) : pdfs.length === 0 ? (
          <Card className="p-10 text-center">
            <FileText className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">No PDFs yet. Upload your first PDF above!</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {pdfs.map(pdf => (
              <Card key={pdf.id} className="overflow-hidden">
                <div
                  className="flex items-center gap-3 p-4 cursor-pointer hover:bg-white/3 transition-colors"
                  onClick={() => setExpanded(expanded === pdf.id ? null : pdf.id)}
                >
                  <div className="w-9 h-9 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{pdf.filename}</p>
                    <p className="text-gray-500 text-xs">{new Date(pdf.created_at).toLocaleDateString()}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={e => { e.stopPropagation(); deletePdf(pdf.id); }} className="text-gray-500 hover:text-red-400 transition-colors p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                    {expanded === pdf.id ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                  </div>
                </div>
                {expanded === pdf.id && (
                  <div className="px-4 pb-4 space-y-4 border-t border-white/10 pt-4">
                    {pdf.summary && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-400 uppercase mb-2">Summary</h4>
                        <p className="text-gray-300 text-sm leading-relaxed">{pdf.summary}</p>
                      </div>
                    )}
                    {Array.isArray(pdf.key_points) && pdf.key_points.length > 0 && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-400 uppercase mb-2">Key Points</h4>
                        <ul className="space-y-1">
                          {(pdf.key_points as string[]).map((point, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                              <span className="text-blue-400 font-bold mt-0.5 flex-shrink-0">•</span>
                              {point}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {pdf.important_notes && (
                      <div>
                        <h4 className="text-xs font-semibold text-gray-400 uppercase mb-2">Important Notes</h4>
                        <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-line">{pdf.important_notes}</p>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
