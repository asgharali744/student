import { Shield } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';

const sections = [
  { title: 'Information We Collect', content: 'We collect information you provide directly, such as your name, email address, and content you create using our services (notes, chats, quizzes). We also collect usage data to improve our services.' },
  { title: 'How We Use Your Information', content: 'We use your information to provide and improve StudyNova AI services, authenticate your account, process your AI requests, and communicate important updates.' },
  { title: 'Data Storage & Security', content: 'Your data is stored securely using Supabase with row-level security. All data is encrypted in transit and at rest. We never sell your personal data to third parties.' },
  { title: 'AI Content Processing', content: 'Your chat messages and documents are sent to AI providers (like Google Gemini) to generate responses. We do not retain this data for training purposes beyond what providers require.' },
  { title: 'Cookies', content: 'We use essential cookies for authentication. We do not use tracking cookies for advertising purposes.' },
  { title: 'Your Rights', content: 'You have the right to access, correct, or delete your personal data at any time. Contact us at hello@studynova.ai to exercise these rights.' },
  { title: 'Contact Us', content: 'If you have questions about this privacy policy, please contact us at hello@studynova.ai.' },
];

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />
      <div className="pt-24 pb-20 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-blue-600/15 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-3xl font-extrabold text-white">Privacy Policy</h1>
              <p className="text-gray-500 text-sm">Last updated: May 2026</p>
            </div>
          </div>
          <div className="space-y-6">
            {sections.map(s => (
              <div key={s.title} className="bg-slate-800/60 border border-white/10 rounded-xl p-5">
                <h2 className="font-semibold text-white mb-2">{s.title}</h2>
                <p className="text-gray-400 text-sm leading-relaxed">{s.content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
