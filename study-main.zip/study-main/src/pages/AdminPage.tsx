import { useState, useEffect } from 'react';
import { Users, MessageSquare, FileText, BrainCircuit, Shield, TrendingUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import { Spinner } from '../components/ui/Loader';
import { Link } from 'react-router-dom';

type UserRow = { id: string; full_name: string; role: string; plan: string; credits: number; created_at: string };

export default function AdminPage() {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [stats, setStats] = useState({ users: 0, chats: 0, notes: 0, quizzes: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.role === 'admin') loadData();
  }, [profile]);

  async function loadData() {
    setLoading(true);
    const [usersRes, chatsRes, notesRes, quizzesRes] = await Promise.all([
      supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(20),
      supabase.from('chats').select('id', { count: 'exact', head: true }),
      supabase.from('notes').select('id', { count: 'exact', head: true }),
      supabase.from('quizzes').select('id', { count: 'exact', head: true }),
    ]);
    if (usersRes.data) setUsers(usersRes.data as UserRow[]);
    setStats({ users: usersRes.count ?? 0, chats: chatsRes.count ?? 0, notes: notesRes.count ?? 0, quizzes: quizzesRes.count ?? 0 });
    setLoading(false);
  }

  async function toggleRole(userId: string, currentRole: string) {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    await supabase.from('profiles').update({ role: newRole }).eq('id', userId);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
  }

  if (profile?.role !== 'admin') {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center h-full p-6 text-center">
          <Shield className="w-12 h-12 text-gray-600 mb-4" />
          <h2 className="text-white font-semibold text-lg mb-2">Access Denied</h2>
          <p className="text-gray-400 text-sm mb-4">You don't have admin access.</p>
          <Link to="/dashboard" className="text-blue-400 hover:text-blue-300 text-sm">Back to Dashboard</Link>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-yellow-400" />
          <div>
            <h1 className="text-xl font-bold text-white">Admin Panel</h1>
            <p className="text-gray-400 text-sm">Platform overview and user management</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: Users, label: 'Total Users', value: users.length, color: 'text-blue-400' },
            { icon: MessageSquare, label: 'Total Chats', value: stats.chats, color: 'text-cyan-400' },
            { icon: FileText, label: 'Total Notes', value: stats.notes, color: 'text-orange-400' },
            { icon: BrainCircuit, label: 'Total Quizzes', value: stats.quizzes, color: 'text-pink-400' },
          ].map(({ icon: Icon, label, value, color }) => (
            <Card key={label} className="p-4">
              <Icon className={`w-5 h-5 ${color} mb-2`} />
              <p className="text-2xl font-bold text-white">{value}</p>
              <p className="text-gray-500 text-xs">{label}</p>
            </Card>
          ))}
        </div>

        {/* Growth Chart Placeholder */}
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <h2 className="font-semibold text-white">User Growth</h2>
          </div>
          <div className="h-32 flex items-end gap-2">
            {[30, 45, 38, 60, 55, 70, 80, 75, 90, 85, 95, 100].map((h, i) => (
              <div key={i} className="flex-1 bg-gradient-to-t from-blue-600 to-cyan-400 rounded-sm opacity-70 transition-all hover:opacity-100" style={{ height: `${h}%` }} />
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600 mt-1">
            <span>Jan</span><span>Dec</span>
          </div>
        </Card>

        {/* Users Table */}
        <Card className="overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h2 className="font-semibold text-white">Recent Users</h2>
          </div>
          {loading ? (
            <div className="flex justify-center py-8"><Spinner /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left text-gray-500 font-medium px-4 py-3">User</th>
                    <th className="text-left text-gray-500 font-medium px-4 py-3">Plan</th>
                    <th className="text-left text-gray-500 font-medium px-4 py-3">Credits</th>
                    <th className="text-left text-gray-500 font-medium px-4 py-3">Role</th>
                    <th className="text-left text-gray-500 font-medium px-4 py-3">Joined</th>
                    <th className="text-left text-gray-500 font-medium px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(user => (
                    <tr key={user.id} className="border-b border-white/5 hover:bg-white/3 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full flex items-center justify-center text-xs font-bold text-white">
                            {(user.full_name || 'U')[0].toUpperCase()}
                          </div>
                          <span className="text-gray-300 truncate max-w-32">{user.full_name || 'Unknown'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={user.plan === 'free' ? 'gray' : 'blue'}>{user.plan}</Badge>
                      </td>
                      <td className="px-4 py-3 text-gray-400">{user.credits}</td>
                      <td className="px-4 py-3">
                        <Badge variant={user.role === 'admin' ? 'yellow' : 'gray'}>{user.role}</Badge>
                      </td>
                      <td className="px-4 py-3 text-gray-500 text-xs">{new Date(user.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => toggleRole(user.id, user.role)}
                          className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
                        >
                          {user.role === 'admin' ? 'Remove Admin' : 'Make Admin'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
