import { Link } from 'react-router-dom';
import {
  MessageSquare, FileText, BookOpen, BrainCircuit, Languages, Zap,
  Mic, Globe, Shield, Smartphone, ArrowRight, CheckCircle
} from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';

const mainFeatures = [
  {
    icon: MessageSquare, title: 'AI Chat Assistant', color: 'from-blue-500 to-cyan-400',
    desc: 'ChatGPT-style conversational AI that supports both Urdu and English. Ask anything, get detailed explanations, solve problems step by step, and save chat history automatically.',
    bullets: ['Urdu + English bilingual support', 'Chat history saved automatically', 'Copy responses with one click', 'Voice input support'],
    href: '/chat',
  },
  {
    icon: FileText, title: 'PDF Summary Tool', color: 'from-emerald-500 to-teal-400',
    desc: 'Upload any PDF and our AI instantly extracts, analyzes, and summarizes the content. Get key points, important notes, and MCQs generated automatically.',
    bullets: ['Instant AI-powered summaries', 'Key points extraction', 'Auto-generated MCQs', 'Important notes highlight'],
    href: '/pdf-summary',
  },
  {
    icon: BookOpen, title: 'Notes Generator', color: 'from-orange-500 to-amber-400',
    desc: 'Generate comprehensive study notes from any topic in seconds. Choose from short, long, bullet-point, or exam-prep formats in your preferred language.',
    bullets: ['4 note formats available', 'English & Urdu support', 'Pin & organize notes', 'Copy & export easily'],
    href: '/notes',
  },
  {
    icon: BrainCircuit, title: 'AI Quiz Generator', color: 'from-pink-500 to-rose-400',
    desc: 'Create interactive quizzes on any topic with configurable difficulty levels. Get instant feedback, explanations, and track your scores.',
    bullets: ['3 difficulty levels', 'Detailed explanations', 'Score tracking', 'Retry anytime'],
    href: '/quiz',
  },
  {
    icon: Languages, title: 'AI Translator', color: 'from-teal-500 to-blue-400',
    desc: 'Translate between Urdu, English, and Hindi with AI-powered grammar correction. Perfect for students studying in multiple languages.',
    bullets: ['Urdu ↔ English ↔ Hindi', 'AI grammar correction', 'Text-to-speech output', 'One-click copy'],
    href: '/translate',
  },
  {
    icon: Zap, title: 'Homework Solver', color: 'from-yellow-500 to-orange-400',
    desc: 'Struggling with homework? Simply type your question or upload an image, and our AI provides clear, step-by-step solutions with explanations.',
    bullets: ['Step-by-step solutions', 'Math, Science, History & more', 'Clear explanations', 'Works for all grades'],
    href: '/chat',
  },
];

const extras = [
  { icon: Mic, label: 'Voice Input', desc: 'Speak your questions' },
  { icon: Globe, label: 'Multi-language', desc: 'English, Urdu, Hindi' },
  { icon: Shield, label: 'Secure & Private', desc: 'Your data stays yours' },
  { icon: Smartphone, label: 'Mobile First', desc: 'Works on all devices' },
];

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />
      <div className="pt-24 pb-20">
        {/* Hero */}
        <div className="text-center px-4 mb-20">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
            Powerful AI Tools for
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">Every Student</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Six comprehensive AI-powered tools built to help you learn faster, study smarter, and ace every exam.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="max-w-6xl mx-auto px-4 space-y-12">
          {mainFeatures.map(({ icon: Icon, title, color, desc, bullets, href }, i) => (
            <div key={title} className={`flex flex-col ${i % 2 === 1 ? 'md:flex-row-reverse' : 'md:flex-row'} gap-8 items-center`}>
              <div className="flex-1">
                <div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-2xl flex items-center justify-center mb-4 shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">{title}</h2>
                <p className="text-gray-400 leading-relaxed mb-4">{desc}</p>
                <ul className="space-y-2 mb-6">
                  {bullets.map(b => (
                    <li key={b} className="flex items-center gap-2 text-sm text-gray-300">
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      {b}
                    </li>
                  ))}
                </ul>
                <Link to={href}>
                  <Button variant="outline" icon={<ArrowRight className="w-4 h-4" />}>Try {title}</Button>
                </Link>
              </div>
              <div className="flex-1 bg-slate-800/60 border border-white/10 rounded-2xl p-6 max-w-sm w-full">
                <div className={`w-full h-40 bg-gradient-to-br ${color} rounded-xl opacity-20`} />
                <div className="mt-4 space-y-2">
                  {[1,2,3].map(n => (
                    <div key={n} className="h-3 bg-white/10 rounded-full" style={{ width: `${70 + n * 8}%` }} />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Extras */}
        <div className="max-w-4xl mx-auto px-4 mt-20">
          <h2 className="text-2xl font-bold text-white text-center mb-8">Plus Much More</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {extras.map(({ icon: Icon, label, desc }) => (
              <div key={label} className="bg-slate-800/60 border border-white/10 rounded-xl p-4 text-center">
                <div className="w-10 h-10 bg-blue-600/15 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Icon className="w-5 h-5 text-blue-400" />
                </div>
                <p className="text-white text-sm font-medium">{label}</p>
                <p className="text-gray-500 text-xs mt-1">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16 px-4">
          <Link to="/register">
            <Button size="lg" icon={<Zap className="w-5 h-5" />}>Get Started Free</Button>
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
