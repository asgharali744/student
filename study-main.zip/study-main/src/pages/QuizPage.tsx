import { useState, useEffect } from 'react';
import { BrainCircuit, Plus, Trophy, ChevronRight, RotateCcw } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Quiz, QuizQuestion } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Button from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import Card from '../components/ui/Card';
import { Spinner } from '../components/ui/Loader';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

type ActiveQuiz = { quiz: Quiz; current: number; selected: number | null; answers: (number | null)[]; finished: boolean };

export default function QuizPage() {
  const { user } = useAuth();
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState('medium');
  const [count, setCount] = useState('5');
  const [generating, setGenerating] = useState(false);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [active, setActive] = useState<ActiveQuiz | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { if (user) loadQuizzes(); }, [user]);

  async function loadQuizzes() {
    setLoading(true);
    const { data } = await supabase.from('quizzes').select('*').eq('user_id', user!.id).order('created_at', { ascending: false });
    if (data) setQuizzes(data as Quiz[]);
    setLoading(false);
  }

  async function generateQuiz() {
    if (!topic.trim() || generating) return;
    setGenerating(true);
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/ai-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` },
        body: JSON.stringify({
          messages: [{
            role: 'user',
            content: `Generate ${count} ${difficulty} difficulty multiple choice questions about "${topic}". Return ONLY a valid JSON array like: [{"question":"...","options":["A","B","C","D"],"correct":0,"explanation":"..."}]. No extra text.`
          }],
          language: 'en',
          type: 'quiz',
        }),
      });
      const result = await response.json();
      let questions: QuizQuestion[] = [];
      try {
        const jsonMatch = result.content.match(/\[[\s\S]*\]/);
        if (jsonMatch) questions = JSON.parse(jsonMatch[0]);
      } catch { questions = []; }

      if (questions.length === 0) { alert('Could not parse quiz. Try again.'); setGenerating(false); return; }

      const { data } = await supabase.from('quizzes').insert({
        user_id: user!.id, title: topic, topic, difficulty, questions
      }).select().single();
      if (data) {
        const quiz = data as Quiz;
        setQuizzes(prev => [quiz, ...prev]);
        startQuiz(quiz);
      }
      setTopic('');
    } catch { alert('Error generating quiz.'); }
    setGenerating(false);
  }

  function startQuiz(quiz: Quiz) {
    setActive({ quiz, current: 0, selected: null, answers: new Array(quiz.questions.length).fill(null), finished: false });
  }

  function selectAnswer(idx: number) {
    if (!active || active.selected !== null) return;
    setActive(prev => prev ? { ...prev, selected: idx } : null);
  }

  function nextQuestion() {
    if (!active) return;
    const newAnswers = [...active.answers];
    newAnswers[active.current] = active.selected;
    const next = active.current + 1;
    if (next >= active.quiz.questions.length) {
      const score = newAnswers.filter((a, i) => a === active.quiz.questions[i].correct).length;
      supabase.from('quizzes').update({ score, completed: true }).eq('id', active.quiz.id);
      setActive(prev => prev ? { ...prev, answers: newAnswers, finished: true } : null);
      setQuizzes(prev => prev.map(q => q.id === active.quiz.id ? { ...q, score, completed: true } : q));
    } else {
      setActive(prev => prev ? { ...prev, current: next, selected: null, answers: newAnswers } : null);
    }
  }

  if (active) {
    const q = active.quiz.questions[active.current];
    if (active.finished) {
      const score = active.answers.filter((a, i) => a === active.quiz.questions[i].correct).length;
      const pct = Math.round((score / active.quiz.questions.length) * 100);
      return (
        <DashboardLayout>
          <div className="p-6 max-w-xl mx-auto">
            <Card className="p-8 text-center">
              <Trophy className="w-14 h-14 text-yellow-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-1">Quiz Complete!</h2>
              <p className="text-gray-400 mb-6">{active.quiz.title}</p>
              <div className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400 mb-2">{pct}%</div>
              <p className="text-gray-400 mb-6">{score} / {active.quiz.questions.length} correct</p>
              <div className="space-y-3 text-left mb-6">
                {active.quiz.questions.map((question, i) => {
                  const userAnswer = active.answers[i];
                  const correct = userAnswer === question.correct;
                  return (
                    <div key={i} className={`p-3 rounded-xl border text-sm ${correct ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                      <p className="text-white font-medium mb-1">{question.question}</p>
                      <p className={`text-xs ${correct ? 'text-emerald-400' : 'text-red-400'}`}>
                        Your answer: {userAnswer !== null ? question.options[userAnswer] : 'None'} {correct ? '✓' : '✗'}
                      </p>
                      {!correct && <p className="text-xs text-gray-400">Correct: {question.options[question.correct]}</p>}
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-3">
                <Button variant="ghost" fullWidth onClick={() => startQuiz(active.quiz)} icon={<RotateCcw className="w-4 h-4" />}>Retry</Button>
                <Button fullWidth onClick={() => setActive(null)}>Back to Quizzes</Button>
              </div>
            </Card>
          </div>
        </DashboardLayout>
      );
    }

    return (
      <DashboardLayout>
        <div className="p-6 max-w-xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-white">{active.quiz.title}</h2>
            <span className="text-gray-400 text-sm">{active.current + 1} / {active.quiz.questions.length}</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-1.5">
            <div className="bg-gradient-to-r from-blue-500 to-cyan-400 h-1.5 rounded-full transition-all" style={{ width: `${((active.current + 1) / active.quiz.questions.length) * 100}%` }} />
          </div>
          <Card className="p-6">
            <p className="text-white font-semibold mb-6 text-base">{q.question}</p>
            <div className="space-y-3">
              {q.options.map((opt, i) => {
                let cls = 'border-white/10 text-gray-300 hover:border-blue-500/50 hover:bg-blue-500/10 cursor-pointer';
                if (active.selected !== null) {
                  if (i === q.correct) cls = 'border-emerald-500/60 bg-emerald-500/10 text-emerald-300';
                  else if (i === active.selected) cls = 'border-red-500/60 bg-red-500/10 text-red-300';
                  else cls = 'border-white/5 text-gray-500';
                } else if (active.selected === i) cls = 'border-blue-500/60 bg-blue-500/10 text-blue-300';
                return (
                  <button
                    key={i}
                    onClick={() => selectAnswer(i)}
                    className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-all ${cls}`}
                  >
                    <span className="font-medium mr-2">{String.fromCharCode(65 + i)}.</span> {opt}
                  </button>
                );
              })}
            </div>
            {active.selected !== null && q.explanation && (
              <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                <p className="text-blue-300 text-xs"><strong>Explanation:</strong> {q.explanation}</p>
              </div>
            )}
          </Card>
          {active.selected !== null && (
            <Button fullWidth onClick={nextQuestion} icon={<ChevronRight className="w-4 h-4" />}>
              {active.current + 1 === active.quiz.questions.length ? 'Finish Quiz' : 'Next Question'}
            </Button>
          )}
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-xl font-bold text-white">Quiz Generator</h1>
          <p className="text-gray-400 text-sm">Generate AI-powered quizzes from any topic</p>
        </div>

        <Card glass className="p-5 space-y-4">
          <Input label="Topic" placeholder="e.g. Chemical Reactions, World History..." value={topic} onChange={e => setTopic(e.target.value)} />
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-36">
              <label className="text-xs font-medium text-gray-400 mb-1.5 block">Difficulty</label>
              <select value={difficulty} onChange={e => setDifficulty(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60">
                <option value="easy" className="bg-slate-800">Easy</option>
                <option value="medium" className="bg-slate-800">Medium</option>
                <option value="hard" className="bg-slate-800">Hard</option>
              </select>
            </div>
            <div className="flex-1 min-w-36">
              <label className="text-xs font-medium text-gray-400 mb-1.5 block">Questions</label>
              <select value={count} onChange={e => setCount(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500/60">
                {['5', '10', '15', '20'].map(n => <option key={n} value={n} className="bg-slate-800">{n} Questions</option>)}
              </select>
            </div>
            <div className="flex items-end">
              <Button onClick={generateQuiz} loading={generating} icon={<Plus className="w-4 h-4" />}>
                Generate Quiz
              </Button>
            </div>
          </div>
        </Card>

        {loading ? (
          <div className="flex justify-center py-8"><Spinner /></div>
        ) : quizzes.length === 0 ? (
          <Card className="p-10 text-center">
            <BrainCircuit className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">No quizzes yet. Generate your first quiz above!</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quizzes.map(quiz => (
              <Card key={quiz.id} hover className="p-4 cursor-pointer" onClick={() => startQuiz(quiz)}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-white text-sm">{quiz.title}</h3>
                    <p className="text-gray-500 text-xs capitalize mt-0.5">{quiz.difficulty} · {quiz.questions.length} questions</p>
                  </div>
                  {quiz.completed && (
                    <div className="flex items-center gap-1 bg-yellow-500/10 border border-yellow-500/20 rounded-full px-2 py-0.5">
                      <Trophy className="w-3 h-3 text-yellow-400" />
                      <span className="text-xs text-yellow-400 font-medium">{Math.round((quiz.score / quiz.questions.length) * 100)}%</span>
                    </div>
                  )}
                </div>
                <Button variant="ghost" size="sm" fullWidth>
                  {quiz.completed ? 'Retake Quiz' : 'Start Quiz'}
                </Button>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
