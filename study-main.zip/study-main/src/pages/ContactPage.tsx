import { useState, FormEvent } from 'react';
import { Mail, MessageSquare, Send } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';
import { Input, Textarea } from '../components/ui/Input';

export default function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />
      <div className="pt-24 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-extrabold text-white mb-4">Get in Touch</h1>
            <p className="text-gray-400 text-lg">Have a question or feedback? We'd love to hear from you.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white mb-4">Contact Information</h2>
                {[
                  { icon: Mail, title: 'Email', info: 'hello@studynova.ai' },
                  { icon: MessageSquare, title: 'Support Chat', info: 'Available 9am–6pm PKT' },
                ].map(({ icon: Icon, title, info }) => (
                  <div key={title} className="flex items-center gap-3 p-4 bg-slate-800/60 border border-white/10 rounded-xl mb-3">
                    <div className="w-10 h-10 bg-blue-600/15 rounded-xl flex items-center justify-center">
                      <Icon className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium text-white text-sm">{title}</p>
                      <p className="text-gray-400 text-sm">{info}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-gradient-to-br from-blue-600/15 to-cyan-600/15 border border-blue-500/30 rounded-2xl p-6">
                <h3 className="font-semibold text-white mb-2">Common Questions</h3>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• How do I reset my password?</li>
                  <li>• How do AI credits work?</li>
                  <li>• Is my data private?</li>
                  <li>• How to cancel subscription?</li>
                </ul>
              </div>
            </div>

            <div className="bg-slate-800/60 border border-white/10 rounded-2xl p-6">
              {sent ? (
                <div className="flex flex-col items-center justify-center h-full text-center py-8">
                  <div className="w-14 h-14 bg-emerald-500/20 rounded-full flex items-center justify-center mb-4">
                    <Send className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-2">Message Sent!</h3>
                  <p className="text-gray-400 text-sm">We'll get back to you within 24 hours.</p>
                  <button onClick={() => { setSent(false); setName(''); setEmail(''); setMessage(''); }} className="mt-4 text-blue-400 text-sm hover:text-blue-300">
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <h2 className="font-semibold text-white mb-4">Send a Message</h2>
                  <Input label="Name" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} required />
                  <Input label="Email" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
                  <Textarea label="Message" placeholder="How can we help?" value={message} onChange={e => setMessage(e.target.value)} rows={5} required />
                  <Button type="submit" fullWidth icon={<Send className="w-4 h-4" />}>Send Message</Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
