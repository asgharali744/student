import { Link } from 'react-router-dom';
import { CheckCircle, X, Zap } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';

const plans = [
  {
    name: 'Free', price: '$0', period: '/month', variant: 'ghost' as const,
    desc: 'Perfect for getting started',
    features: [
      { text: '20 AI credits/month', included: true },
      { text: 'AI Chat (10 msgs/day)', included: true },
      { text: 'PDF Summary (2/month)', included: true },
      { text: 'Basic Notes Generator', included: true },
      { text: 'Quiz Generator (5 quizzes/month)', included: true },
      { text: 'Text Translation', included: true },
      { text: 'Priority speed', included: false },
      { text: 'Voice input', included: false },
      { text: 'Export notes', included: false },
      { text: 'API access', included: false },
    ],
  },
  {
    name: 'Pro', price: '$9', period: '/month', variant: 'primary' as const, popular: true,
    desc: 'Best for serious students',
    features: [
      { text: '500 AI credits/month', included: true },
      { text: 'Unlimited AI Chat', included: true },
      { text: 'PDF Summary (50/month)', included: true },
      { text: 'Advanced Notes (all types)', included: true },
      { text: 'Unlimited Quizzes', included: true },
      { text: 'Advanced Translation', included: true },
      { text: 'Priority speed', included: true },
      { text: 'Voice input', included: true },
      { text: 'Export notes', included: true },
      { text: 'API access', included: false },
    ],
  },
  {
    name: 'Elite', price: '$19', period: '/month', variant: 'secondary' as const,
    desc: 'For power users & teams',
    features: [
      { text: 'Unlimited AI credits', included: true },
      { text: 'Unlimited AI Chat', included: true },
      { text: 'Unlimited PDF Summaries', included: true },
      { text: 'All Note types + templates', included: true },
      { text: 'Unlimited Quizzes', included: true },
      { text: 'All languages + dialects', included: true },
      { text: 'Fastest speed', included: true },
      { text: 'Voice input + output', included: true },
      { text: 'Export everything', included: true },
      { text: 'API access', included: true },
    ],
  },
];

const faqs = [
  { q: 'Can I cancel anytime?', a: 'Yes! You can cancel your subscription at any time. No contracts, no commitment.' },
  { q: 'What counts as an AI credit?', a: 'Each AI interaction (chat message, note generation, translation, quiz) uses one credit.' },
  { q: 'Is there a free trial for Pro?', a: 'Yes! All new accounts start with 20 free credits to try all features.' },
  { q: 'Does it work in Urdu?', a: 'Absolutely! Our AI fully supports Urdu language for chat, notes, and translation.' },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <Header />
      <div className="pt-24 pb-20">
        <div className="text-center px-4 mb-14">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-gray-400 text-lg max-w-lg mx-auto">Start free. No credit card required. Upgrade when you need more.</p>
        </div>

        {/* Plans */}
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-6 border flex flex-col ${
                plan.popular
                  ? 'bg-blue-600/15 border-blue-500/50 shadow-2xl shadow-blue-500/10 scale-[1.02]'
                  : 'bg-slate-800/60 border-white/10'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-cyan-500 text-white text-xs font-bold px-4 py-1 rounded-full shadow-lg">
                  Most Popular
                </div>
              )}
              <div className="mb-6">
                <p className="text-gray-400 text-sm font-medium">{plan.name}</p>
                <div className="flex items-baseline gap-1 mt-1 mb-1">
                  <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                  <span className="text-gray-500">{plan.period}</span>
                </div>
                <p className="text-gray-500 text-sm">{plan.desc}</p>
              </div>

              <ul className="space-y-2.5 mb-8 flex-1">
                {plan.features.map(f => (
                  <li key={f.text} className="flex items-center gap-2 text-sm">
                    {f.included
                      ? <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      : <X className="w-4 h-4 text-gray-600 flex-shrink-0" />}
                    <span className={f.included ? 'text-gray-300' : 'text-gray-600'}>{f.text}</span>
                  </li>
                ))}
              </ul>

              <Link to="/register">
                <Button variant={plan.variant} fullWidth>
                  {plan.name === 'Free' ? 'Get Started Free' : `Start ${plan.name}`}
                </Button>
              </Link>
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="max-w-2xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-white text-center mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faqs.map(faq => (
              <div key={faq.q} className="bg-slate-800/60 border border-white/10 rounded-xl p-5">
                <p className="font-semibold text-white text-sm mb-2">{faq.q}</p>
                <p className="text-gray-400 text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16 px-4">
          <p className="text-gray-400 mb-4">Still have questions?</p>
          <Link to="/contact">
            <Button variant="ghost" icon={<Zap className="w-4 h-4" />}>Contact Us</Button>
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
}
