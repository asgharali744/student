import { useState, FormEvent } from 'react';
import { User, Save, Zap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import DashboardLayout from '../components/layout/DashboardLayout';
import Button from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';

export default function ProfilePage() {
  const { user, profile, refreshProfile } = useAuth();
  const [name, setName] = useState(profile?.full_name || '');
  const [lang, setLang] = useState(profile?.language_preference || 'en');
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleSave(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    await supabase.from('profiles').update({ full_name: name, language_preference: lang, updated_at: new Date().toISOString() }).eq('id', user!.id);
    await refreshProfile();
    setSaving(false);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-xl mx-auto space-y-6">
        <div>
          <h1 className="text-xl font-bold text-white">Profile</h1>
          <p className="text-gray-400 text-sm">Manage your account settings</p>
        </div>

        {/* Avatar */}
        <Card className="p-6 flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center text-2xl font-bold text-white shadow-lg">
            {(profile?.full_name || user?.email || 'U')[0].toUpperCase()}
          </div>
          <div>
            <p className="font-semibold text-white">{profile?.full_name || 'Student'}</p>
            <p className="text-gray-400 text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant={profile?.plan === 'free' ? 'gray' : 'blue'}>{profile?.plan === 'free' ? 'Free Plan' : 'Pro Plan'}</Badge>
              <div className="flex items-center gap-1 text-xs text-blue-400">
                <Zap className="w-3 h-3" /> {profile?.credits} credits
              </div>
            </div>
          </div>
        </Card>

        {/* Settings Form */}
        <Card className="p-6">
          <h2 className="font-semibold text-white mb-4">Account Settings</h2>
          {success && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-emerald-300 mb-4">
              Profile updated successfully!
            </div>
          )}
          <form onSubmit={handleSave} className="space-y-4">
            <Input
              label="Full Name"
              value={name}
              onChange={e => setName(e.target.value)}
              icon={<User className="w-4 h-4" />}
              placeholder="Your full name"
            />
            <Input
              label="Email"
              value={user?.email || ''}
              disabled
              hint="Email cannot be changed"
            />
            <div>
              <label className="text-sm font-medium text-gray-300 mb-1.5 block">Language Preference</label>
              <select
                value={lang}
                onChange={e => setLang(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500/60"
              >
                <option value="en" className="bg-slate-800">English</option>
                <option value="ur" className="bg-slate-800">Urdu</option>
              </select>
            </div>
            <Button type="submit" loading={saving} icon={<Save className="w-4 h-4" />}>
              Save Changes
            </Button>
          </form>
        </Card>

        {/* Plan */}
        {profile?.plan === 'free' && (
          <Card className="p-6 bg-gradient-to-r from-blue-600/15 to-cyan-600/15 border-blue-500/30">
            <h3 className="font-semibold text-white mb-1">Upgrade to Pro</h3>
            <p className="text-gray-400 text-sm mb-4">Get 500 credits/month, unlimited features, and priority support.</p>
            <Button size="sm">Upgrade Now — $9/month</Button>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
